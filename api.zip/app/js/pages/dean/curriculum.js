/**
 * Dean — Program Subjects
 * Shows subjects belonging to each program in the dean's department.
 * Dean can add subjects to a program's curriculum and offer them.
 */
import { Api } from '../../api.js';

let _programs    = [];
let _subjects    = [];
let _allSubjects = [];
let _activeProg  = null;

export async function render(container) {
    container.innerHTML = `<style>${css()}</style><div class="ps-boot"><div class="ps-spin"></div></div>`;

    const [progRes, allSubjRes] = await Promise.all([
        Api.get('/CurriculumAPI.php?action=programs'),
        Api.get('/SubjectsAPI.php?action=all'),
    ]);

    _programs    = progRes.success    ? progRes.data    : [];
    _allSubjects = allSubjRes.success ? allSubjRes.data : [];

    if (!_programs.length) {
        container.innerHTML = `<style>${css()}</style>
        <div class="ps-empty-full">
            <h3>No programs assigned</h3>
            <p>Your department has no programs yet. Ask the admin to link programs to your department.</p>
        </div>`;
        return;
    }

    _activeProg = _programs[0];

    container.innerHTML = `<style>${css()}</style>
    <div class="ps-page">

        <div class="ps-header">
            <div class="ps-header-left">
                <h2 class="ps-title">Program Subjects</h2>
                <p class="ps-subtitle">Manage which subjects belong to each program in your department</p>
            </div>
            <button class="ps-btn-add" id="ps-add-btn">+ Add Subject to Program</button>
        </div>

        <!-- Program tabs -->
        <div class="ps-prog-tabs" id="ps-prog-tabs">
            ${_programs.map((p, i) => `
                <button class="ps-prog-tab ${i === 0 ? 'active' : ''}" data-pid="${p.program_id}">
                    ${esc(p.program_code)}
                    <span class="ps-prog-tab-name">${esc(p.program_name)}</span>
                </button>
            `).join('')}
        </div>

        <!-- Subject table -->
        <div id="ps-table-area">
            <div class="ps-boot"><div class="ps-spin"></div></div>
        </div>

    </div>

    <!-- Add Subject modal -->
    <div id="ps-modal" class="ps-backdrop" style="display:none;">
        <div class="ps-modal">
            <div class="ps-modal-hdr">
                <h3>Add Subject to <span id="ps-modal-prog-name"></span></h3>
                <button class="ps-modal-close" id="ps-modal-close">&times;</button>
            </div>
            <div class="ps-modal-body">
                <div class="ps-modal-msg" id="ps-modal-msg" style="display:none;"></div>
                <input type="text" class="ps-modal-search" id="ps-modal-search" placeholder="Search subjects…" autocomplete="off">
                <div class="ps-modal-list" id="ps-modal-list"></div>
            </div>
        </div>
    </div>

    <!-- Offer modal -->
    <div id="ps-offer-modal" class="ps-backdrop" style="display:none;">
        <div class="ps-modal ps-modal--sm">
            <div class="ps-modal-hdr">
                <h3>Offer Subject</h3>
                <button class="ps-modal-close" id="ps-offer-close">&times;</button>
            </div>
            <div class="ps-modal-body">
                <div class="ps-modal-msg" id="ps-offer-msg" style="display:none;"></div>
                <input type="hidden" id="ps-offer-subj-id">
                <div class="ps-field">
                    <label>Subject</label>
                    <input type="text" id="ps-offer-subj-name" disabled class="ps-field-input ps-field-input--disabled">
                </div>
                <div class="ps-field">
                    <label>Year Level (optional)</label>
                    <select id="ps-offer-batch" class="ps-field-input">
                        <option value="">— All / Not specified —</option>
                        <option value="1st Year">1st Year</option>
                        <option value="2nd Year">2nd Year</option>
                        <option value="3rd Year">3rd Year</option>
                        <option value="4th Year">4th Year</option>
                    </select>
                </div>
                <div class="ps-form-actions">
                    <button class="ps-btn-cancel" id="ps-offer-cancel">Cancel</button>
                    <button class="ps-btn-save" id="ps-offer-save">Create Offering</button>
                </div>
            </div>
        </div>
    </div>
    `;

    await loadProgramSubjects(container, _activeProg);
    bindEvents(container);
}

// ── Load subjects for a program ───────────────────────────────────────────────

async function loadProgramSubjects(container, prog) {
    const area = container.querySelector('#ps-table-area');
    area.innerHTML = `<div class="ps-boot"><div class="ps-spin"></div></div>`;

    const res = await Api.get(`/CurriculumAPI.php?action=view&program_id=${prog.program_id}`);
    _subjects = res.success ? res.data : [];

    renderTable(area, prog);
}

function renderTable(area, prog) {
    if (!_subjects.length) {
        area.innerHTML = `
        <div class="ps-empty">
            <svg width="40" height="40" fill="none" viewBox="0 0 24 24" stroke="#9CA3AF" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
            </svg>
            <p>No subjects in <strong>${esc(prog.program_code)}</strong> yet.</p>
            <button class="ps-btn-add-inline" id="ps-empty-add">Add subjects to this program</button>
        </div>`;
        area.querySelector('#ps-empty-add')?.addEventListener('click', () => openAddModal(area.closest('.ps-page').parentElement));
        return;
    }

    // Group by year level
    const byYear = {};
    _subjects.forEach(s => {
        const yr = s.year_level ? `${s.year_level}${ordinal(s.year_level)} Year` : 'General';
        if (!byYear[yr]) byYear[yr] = [];
        byYear[yr].push(s);
    });

    area.innerHTML = `
    <div class="ps-search-bar">
        <input type="text" id="ps-search" class="ps-search-inp" placeholder="Search subjects…" autocomplete="off">
        <span class="ps-count" id="ps-count">${_subjects.length} subject${_subjects.length !== 1 ? 's' : ''}</span>
    </div>
    <div id="ps-groups">
        ${Object.entries(byYear).map(([yr, list], i) => `
        <div class="ps-year-group">
            <button class="ps-year-toggle ${i === 0 ? 'open' : ''}" data-yr="${yr}">
                <span class="ps-year-toggle-label">
                    <svg class="ps-yr-chevron" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                        <polyline points="6 9 12 15 18 9"/>
                    </svg>
                    ${yr}
                </span>
                <span class="ps-year-badge">${list.length} subject${list.length !== 1 ? 's' : ''}</span>
            </button>
            <div class="ps-year-body ${i === 0 ? 'open' : ''}">
                <table class="ps-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Subject Name</th>
                            <th>Units</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        ${list.map(s => subjectRow(s)).join('')}
                    </tbody>
                </table>
            </div>
        </div>`).join('')}
    </div>`;

    // Toggle accordion
    area.querySelectorAll('.ps-year-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
            const body = btn.nextElementSibling;
            const open = btn.classList.toggle('open');
            body.classList.toggle('open', open);
        });
    });

    // Search — opens all groups that have a match
    const inp = area.querySelector('#ps-search');
    inp?.addEventListener('input', () => {
        const q = inp.value.toLowerCase();
        let visible = 0;
        area.querySelectorAll('.ps-year-group').forEach(group => {
            const rows = group.querySelectorAll('.ps-tr');
            let groupVisible = 0;
            rows.forEach(tr => {
                const show = !q || tr.dataset.search.includes(q);
                tr.style.display = show ? '' : 'none';
                if (show) groupVisible++;
            });
            visible += groupVisible;
            if (q && groupVisible > 0) {
                group.querySelector('.ps-year-toggle').classList.add('open');
                group.querySelector('.ps-year-body').classList.add('open');
            }
        });
        const countEl = area.querySelector('#ps-count');
        if (countEl) countEl.textContent = `${visible} subject${visible !== 1 ? 's' : ''}`;
    });

    // Offer buttons
    area.querySelectorAll('[data-offer-id]').forEach(btn => {
        btn.addEventListener('click', () => {
            const s = _subjects.find(x => String(x.subject_id) === btn.dataset.offerId);
            if (s) openOfferModal(btn.closest('.ps-page').parentElement, s);
        });
    });
}

function subjectRow(s) {
    return `
    <tr class="ps-tr" data-search="${(s.subject_code + ' ' + s.subject_name).toLowerCase()}">
        <td><span class="ps-code">${esc(s.subject_code)}</span></td>
        <td class="ps-name">${esc(s.subject_name)}</td>
        <td><span class="ps-units">${s.units} u</span></td>
        <td><span class="ps-badge ps-badge--${s.status}">${s.status}</span></td>
        <td class="ps-actions">
            <button class="ps-btn-offer" data-offer-id="${s.subject_id}" title="Create offering so students can enroll">
                Offer
            </button>
        </td>
    </tr>`;
}

// ── Add Subject modal ─────────────────────────────────────────────────────────

async function openAddModal(container) {
    const modal   = container.querySelector('#ps-modal');
    const nameEl  = container.querySelector('#ps-modal-prog-name');
    const listEl  = container.querySelector('#ps-modal-list');
    const searchEl = container.querySelector('#ps-modal-search');
    const msgEl   = container.querySelector('#ps-modal-msg');

    nameEl.textContent = _activeProg.program_code;
    msgEl.style.display = 'none';
    searchEl.value = '';
    listEl.innerHTML = `<div class="ps-boot"><div class="ps-spin"></div></div>`;
    modal.style.display = 'flex';

    const res = await Api.get(`/CurriculumAPI.php?action=available&program_id=${_activeProg.program_id}`);
    const avail = res.success ? res.data : [];

    function renderList(q) {
        const filtered = avail.filter(s =>
            !q || (s.subject_code + ' ' + s.subject_name).toLowerCase().includes(q)
        );
        if (!filtered.length) {
            listEl.innerHTML = `<div class="ps-modal-empty">No subjects found</div>`;
            return;
        }
        listEl.innerHTML = filtered.map(s => `
            <div class="ps-modal-item ${s.in_program == 1 ? 'in-prog' : ''}" data-id="${s.subject_id}">
                <div class="ps-modal-item-info">
                    <span class="ps-code">${esc(s.subject_code)}</span>
                    <span class="ps-modal-item-name">${esc(s.subject_name)}</span>
                    <span class="ps-units">${s.units} u</span>
                </div>
                ${s.in_program == 1
                    ? `<span class="ps-modal-item-tag">In program</span>`
                    : `<button class="ps-modal-item-btn" data-add-id="${s.subject_id}" data-add-code="${esc(s.subject_code)}" data-add-name="${esc(s.subject_name)}">Add</button>`
                }
            </div>
        `).join('');

        listEl.querySelectorAll('[data-add-id]').forEach(btn => {
            btn.addEventListener('click', async () => {
                btn.disabled = true; btn.textContent = '…';
                const r = await Api.post('/CurriculumAPI.php?action=add', {
                    program_id: _activeProg.program_id,
                    subject_id: parseInt(btn.dataset.addId),
                });
                if (r.success) {
                    const item = btn.closest('.ps-modal-item');
                    item.classList.add('in-prog');
                    item.querySelector('.ps-modal-item-info').insertAdjacentHTML('afterend', `<span class="ps-modal-item-tag">In program</span>`);
                    btn.remove();
                    // Refresh table
                    const area = container.querySelector('#ps-table-area');
                    const reloadRes = await Api.get(`/CurriculumAPI.php?action=view&program_id=${_activeProg.program_id}`);
                    _subjects = reloadRes.success ? reloadRes.data : [];
                    renderTable(area, _activeProg);
                } else {
                    showMsg(msgEl, r.message || 'Failed to add subject', 'err');
                    btn.disabled = false; btn.textContent = 'Add';
                }
            });
        });
    }

    renderList('');
    searchEl.addEventListener('input', () => renderList(searchEl.value.toLowerCase()));
}

// ── Offer modal ───────────────────────────────────────────────────────────────

function openOfferModal(container, subj) {
    container.querySelector('#ps-offer-subj-id').value = subj.subject_id;
    container.querySelector('#ps-offer-subj-name').value = `${subj.subject_code} — ${subj.subject_name}`;
    container.querySelector('#ps-offer-batch').value = '';
    const msgEl = container.querySelector('#ps-offer-msg');
    msgEl.style.display = 'none';
    container.querySelector('#ps-offer-modal').style.display = 'flex';
}

// ── Event binding ─────────────────────────────────────────────────────────────

function bindEvents(container) {
    // Program tabs
    container.querySelectorAll('.ps-prog-tab').forEach(tab => {
        tab.addEventListener('click', async () => {
            container.querySelectorAll('.ps-prog-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            _activeProg = _programs.find(p => String(p.program_id) === tab.dataset.pid);
            if (_activeProg) await loadProgramSubjects(container, _activeProg);
        });
    });

    // Add button
    container.querySelector('#ps-add-btn')?.addEventListener('click', () => openAddModal(container));

    // Add modal close
    container.querySelector('#ps-modal-close')?.addEventListener('click', () => {
        container.querySelector('#ps-modal').style.display = 'none';
    });
    container.querySelector('#ps-modal')?.addEventListener('click', e => {
        if (e.target === e.currentTarget) e.currentTarget.style.display = 'none';
    });

    // Offer modal close
    container.querySelector('#ps-offer-close')?.addEventListener('click', () => {
        container.querySelector('#ps-offer-modal').style.display = 'none';
    });
    container.querySelector('#ps-offer-cancel')?.addEventListener('click', () => {
        container.querySelector('#ps-offer-modal').style.display = 'none';
    });
    container.querySelector('#ps-offer-modal')?.addEventListener('click', e => {
        if (e.target === e.currentTarget) e.currentTarget.style.display = 'none';
    });

    // Offer save
    container.querySelector('#ps-offer-save')?.addEventListener('click', async () => {
        const btn    = container.querySelector('#ps-offer-save');
        const msgEl  = container.querySelector('#ps-offer-msg');
        const subjId = parseInt(container.querySelector('#ps-offer-subj-id').value, 10);
        const batch  = container.querySelector('#ps-offer-batch').value || null;

        btn.disabled = true; btn.textContent = 'Creating…';
        const res = await Api.post('/SubjectOfferingsAPI.php?action=create', {
            subject_id: subjId, batch, status: 'open'
        });
        btn.disabled = false; btn.textContent = 'Create Offering';

        if (res.success) {
            showMsg(msgEl, 'Offering created — instructors can now be assigned.', 'ok');
            setTimeout(() => { container.querySelector('#ps-offer-modal').style.display = 'none'; }, 1400);
        } else {
            showMsg(msgEl, res.message || 'Failed to create offering.', 'err');
        }
    });
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function showMsg(el, text, type) {
    el.textContent = text;
    el.className = `ps-modal-msg ps-modal-msg--${type}`;
    el.style.display = 'block';
}

function ordinal(n) {
    const s = ['th','st','nd','rd'];
    const v = n % 100;
    return s[(v - 20) % 10] || s[v] || s[0];
}

function esc(str) {
    const d = document.createElement('div');
    d.textContent = str || '';
    return d.innerHTML;
}

// ── CSS ───────────────────────────────────────────────────────────────────────

function css() { return `
.ps-boot { display:flex; justify-content:center; padding:60px; }
.ps-spin { width:32px; height:32px; border:3px solid #E5E7EB; border-top-color:#00461B; border-radius:50%; animation:psSpin .8s linear infinite; }
@keyframes psSpin { to { transform:rotate(360deg); } }

.ps-page { padding:0 0 40px; }

.ps-header {
    display:flex; align-items:flex-start; justify-content:space-between;
    gap:16px; flex-wrap:wrap; margin-bottom:24px;
}
.ps-title { font-size:22px; font-weight:800; color:#111827; margin:0 0 4px; }
.ps-subtitle { font-size:13px; color:#6B7280; margin:0; }

.ps-btn-add {
    padding:9px 18px; background:#00461B; color:#fff; border:none;
    border-radius:8px; font-size:13px; font-weight:600; cursor:pointer; white-space:nowrap;
}
.ps-btn-add:hover { background:#003515; }

/* Program tabs */
.ps-prog-tabs { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:20px; }
.ps-prog-tab {
    display:flex; flex-direction:column; align-items:flex-start;
    padding:8px 16px; border:1.5px solid #E5E7EB; border-radius:8px;
    background:#fff; cursor:pointer; font-size:13px; font-weight:700;
    color:#374151; transition:all .15s; line-height:1.2;
}
.ps-prog-tab:hover { border-color:#00461B; color:#00461B; }
.ps-prog-tab.active { background:#00461B; color:#fff; border-color:#00461B; }
.ps-prog-tab-name { font-size:11px; font-weight:400; opacity:.8; margin-top:2px; }
.ps-prog-tab.active .ps-prog-tab-name { opacity:.85; }

/* Search bar */
.ps-search-bar { display:flex; align-items:center; gap:12px; margin-bottom:16px; }
.ps-search-inp {
    flex:1; padding:8px 12px; border:1px solid #E5E7EB; border-radius:8px;
    font-size:13px; outline:none; font-family:inherit;
}
.ps-search-inp:focus { border-color:#00461B; box-shadow:0 0 0 2px rgba(0,70,27,.08); }
.ps-count { font-size:13px; color:#6B7280; white-space:nowrap; }

/* Year groups — accordion */
.ps-year-group { margin-bottom:10px; border:1px solid #E5E7EB; border-radius:10px; overflow:hidden; }
.ps-year-toggle {
    width:100%; display:flex; align-items:center; justify-content:space-between;
    padding:13px 16px; background:#F9FAFB; border:none; cursor:pointer;
    font-size:14px; font-weight:700; color:#111827; text-align:left;
    transition:background .15s;
}
.ps-year-toggle:hover { background:#F3F4F6; }
.ps-year-toggle.open { background:#E8F5EC; color:#00461B; }
.ps-year-toggle-label { display:flex; align-items:center; gap:8px; }
.ps-yr-chevron { transition:transform .2s; flex-shrink:0; }
.ps-year-toggle.open .ps-yr-chevron { transform:rotate(180deg); }
.ps-year-badge {
    font-size:12px; font-weight:600; color:#6B7280; background:#fff;
    border:1px solid #E5E7EB; padding:2px 10px; border-radius:10px;
}
.ps-year-toggle.open .ps-year-badge { color:#00461B; border-color:#BBF7D0; background:#F0FDF4; }
.ps-year-body { display:none; }
.ps-year-body.open { display:block; }

/* Table */
.ps-table { width:100%; border-collapse:collapse; background:#fff; border-radius:0; overflow:hidden; border:none; border-top:1px solid #E5E7EB; }
.ps-table th { text-align:left; padding:10px 14px; font-size:11px; font-weight:700; color:#fff; background:#00461B; }
.ps-table td { padding:11px 14px; border-bottom:1px solid #F3F4F6; font-size:13px; vertical-align:middle; }
.ps-tr:last-child td { border-bottom:none; }
.ps-tr:hover td { background:#FAFAFA; }

.ps-code { background:#E8F5E9; color:#1B4D3E; padding:2px 7px; border-radius:4px; font-family:monospace; font-size:12px; font-weight:700; }
.ps-name { font-weight:500; color:#111827; }
.ps-units { background:#F3F4F6; color:#374151; padding:2px 8px; border-radius:10px; font-size:12px; font-weight:600; }
.ps-badge { padding:2px 8px; border-radius:10px; font-size:11px; font-weight:600; text-transform:capitalize; }
.ps-badge--active { background:#E8F5E9; color:#1B4D3E; }
.ps-badge--inactive { background:#FEE2E2; color:#b91c1c; }
.ps-actions { text-align:right; }
.ps-btn-offer {
    padding:5px 12px; background:#EFF6FF; color:#1D4ED8; border:1px solid #BFDBFE;
    border-radius:6px; font-size:12px; font-weight:600; cursor:pointer;
}
.ps-btn-offer:hover { background:#DBEAFE; }

/* Empty states */
.ps-empty {
    text-align:center; padding:48px 24px; color:#6B7280;
    background:#fff; border:1px dashed #E5E7EB; border-radius:10px; margin-top:8px;
}
.ps-empty p { margin:12px 0 16px; }
.ps-empty-full { text-align:center; padding:80px 24px; color:#6B7280; }
.ps-btn-add-inline {
    padding:8px 18px; background:#00461B; color:#fff; border:none;
    border-radius:8px; font-size:13px; font-weight:600; cursor:pointer;
}

/* Modal */
.ps-backdrop {
    position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:1000;
    display:flex; align-items:center; justify-content:center; padding:20px;
}
.ps-modal {
    background:#fff; border-radius:14px; width:100%; max-width:540px;
    box-shadow:0 8px 40px rgba(0,0,0,.18); overflow:hidden; max-height:90vh; display:flex; flex-direction:column;
}
.ps-modal--sm { max-width:420px; }
.ps-modal-hdr {
    background:#00461B; padding:16px 20px; display:flex; align-items:center;
    justify-content:space-between; flex-shrink:0;
}
.ps-modal-hdr h3 { color:#fff; font-size:15px; font-weight:700; margin:0; }
.ps-modal-close { background:none; border:none; color:#fff; font-size:22px; cursor:pointer; line-height:1; opacity:.8; }
.ps-modal-close:hover { opacity:1; }
.ps-modal-body { padding:18px 20px; overflow-y:auto; flex:1; }
.ps-modal-search {
    width:100%; padding:9px 12px; border:1px solid #E5E7EB; border-radius:8px;
    font-size:13px; font-family:inherit; outline:none; box-sizing:border-box; margin-bottom:12px;
}
.ps-modal-search:focus { border-color:#00461B; box-shadow:0 0 0 2px rgba(0,70,27,.08); }
.ps-modal-list { display:flex; flex-direction:column; gap:6px; }
.ps-modal-item {
    display:flex; align-items:center; justify-content:space-between; gap:10px;
    padding:10px 12px; border:1px solid #E5E7EB; border-radius:8px; background:#fff;
}
.ps-modal-item.in-prog { background:#F0FDF4; border-color:#BBF7D0; }
.ps-modal-item-info { display:flex; align-items:center; gap:8px; flex:1; min-width:0; flex-wrap:wrap; }
.ps-modal-item-name { font-size:13px; color:#111827; font-weight:500; }
.ps-modal-item-btn {
    padding:5px 14px; background:#00461B; color:#fff; border:none;
    border-radius:6px; font-size:12px; font-weight:600; cursor:pointer; white-space:nowrap; flex-shrink:0;
}
.ps-modal-item-btn:hover { background:#003515; }
.ps-modal-item-btn:disabled { opacity:.5; cursor:not-allowed; }
.ps-modal-item-tag { font-size:11px; color:#15803D; font-weight:600; white-space:nowrap; flex-shrink:0; }
.ps-modal-empty { text-align:center; padding:24px; color:#9CA3AF; font-size:13px; }

.ps-modal-msg {
    padding:9px 12px; border-radius:7px; font-size:13px; margin-bottom:12px;
}
.ps-modal-msg--ok  { background:#E8F5E9; color:#1B4D3E; }
.ps-modal-msg--err { background:#FEE2E2; color:#b91c1c; }

.ps-field { margin-bottom:14px; }
.ps-field label { display:block; font-size:13px; font-weight:600; color:#374151; margin-bottom:5px; }
.ps-field-input {
    width:100%; padding:9px 12px; border:1px solid #E5E7EB; border-radius:8px;
    font-size:13px; font-family:inherit; box-sizing:border-box; outline:none;
}
.ps-field-input:focus { border-color:#00461B; }
.ps-field-input--disabled { background:#F9FAFB; color:#6B7280; }
.ps-form-actions { display:flex; gap:10px; justify-content:flex-end; margin-top:18px; }
.ps-btn-cancel {
    padding:8px 16px; border:1px solid #E5E7EB; border-radius:8px;
    background:#fff; font-size:13px; font-weight:600; cursor:pointer; color:#374151;
}
.ps-btn-cancel:hover { background:#F9FAFB; }
.ps-btn-save {
    padding:8px 18px; border:none; border-radius:8px;
    background:#00461B; color:#fff; font-size:13px; font-weight:600; cursor:pointer;
}
.ps-btn-save:hover { background:#003515; }
.ps-btn-save:disabled { opacity:.5; cursor:not-allowed; }
`; }
