/**
 * Student Grades — flat class record (all activities + quizzes, no period grouping)
 * My Grades: subject cards → class record per subject
 * Subject tab: same class record view embedded
 */
import { Api } from '../../api.js';
import { Auth } from '../../auth.js';
import { icon, iconLg } from '../../utils/icons.js';
import { curriculumTableCss, esc } from '../../utils/classroom-ui.js';
import { getFullName } from '../../utils/user-display.js';
import {
    buildPeriodGroups, isItemMissing, gradingPeriodTableCss,
} from '../../utils/gradebook-periods.js';
import { bindQuizReviewTriggers } from '../../components/student-quiz-review-modal.js';

const inl = { size: 14, className: 'ui-icon-inline' };
const G = '#00461B';
const G2 = '#006428';
const GL = '#E8F5EC';
const BORDER = '#E5E7EB';

export async function render(container) {
    const hashParams = new URLSearchParams(window.location.hash.split('?')[1] || '');
    const subjectId = hashParams.get('subject_id') || '';
    try {
        await renderGradesView(container, { subjectId, embedded: false });
    } catch (err) {
        console.error('Grades render error:', err);
        container.innerHTML = `<style>${pageCss()}</style><div class="sg-page">${emptyBox('Something went wrong loading your grades. Please refresh and try again.')}</div>`;
    }
}

/** Embed student grades inside a subject tab */
export async function mountStudentGrades(host, { subjectId } = {}) {
    try {
        await renderGradesView(host, { subjectId, embedded: true, lockSubject: true });
    } catch (err) {
        console.error('Grades mount error:', err);
        host.innerHTML = `<style>${pageCss()}</style>${emptyBox('Could not load class record. Please refresh.')}`;
    }
}

async function renderGradesView(container, { subjectId = '', embedded = false, lockSubject = false } = {}) {
    container.innerHTML = `
        <div class="sg-loading"><div class="sg-spin"></div></div>
        <style>${pageCss()}</style>
    `;

    await Auth.getUser?.();
    const me = Auth.user?.() || {};
    const myName = getFullName(me) || 'Student';
    const myStudentId = me.student_id || me.user_id || '';

    const res = await Api.get('/ProgressAPI.php?action=grades');
    const subjects = res.success ? (res.data || []) : [];

    if (!res.success) {
        container.innerHTML = `<style>${pageCss()}</style><div class="sg-page">${emptyBox('Could not load grades. Please try again.')}</div>`;
        return;
    }

    if (subjects.length === 0) {
        container.innerHTML = `<style>${pageCss()}</style><div class="sg-page ${embedded ? 'sg-embedded' : ''}">
            ${embedded ? '' : renderHero('My Grades', 'Track your quiz scores and activity progress')}
            ${emptyBox(lockSubject ? 'No scores recorded for this subject yet.' : 'Enroll in subjects and complete classwork to see your class record here.')}
        </div>`;
        return;
    }

    const activeId = subjectId || String(subjects[0]?.subject_id || '');
    const subject  = subjects.find(s => String(s.subject_id) === String(activeId)) || subjects[0];

    if (!subject) {
        container.innerHTML = `<style>${pageCss()}</style><div class="sg-page">${emptyBox('Subject not found.')}</div>`;
        return;
    }

    if (embedded && lockSubject) {
        renderClassRecordOnly(container, { subject, myName, myStudentId });
        return;
    }

    renderMyGradesPage(container, { subjects, activeSubjectId: String(subject.subject_id), myName, myStudentId });
}

function renderMyGradesPage(container, { subjects, activeSubjectId, myName, myStudentId }) {
    const activeIdx = Math.max(0, subjects.findIndex(s => String(s.subject_id) === String(activeSubjectId)));

    container.innerHTML = `
        <style>${pageCss()}${curriculumTableCss()}</style>
        <div class="sg-page">
            ${renderHero('My Grades', 'Class record — all activities and quizzes')}
            ${subjects.length > 1 ? `
            <div class="sg-subject-bar">
                <label class="sg-subject-bar-label" for="sg-subject-select">Subject</label>
                <div class="sg-subject-select-wrap">
                    <select id="sg-subject-select" class="sg-subject-select">
                        ${subjects.map((s, i) => `
                            <option value="${i}" ${i === activeIdx ? 'selected' : ''}>
                                ${esc(s.subject_code)} — ${esc(s.subject_name)}
                            </option>`).join('')}
                    </select>
                    <svg class="sg-subject-chevron" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
                </div>
                <span class="sg-subject-hint">Select a subject to view your class record</span>
            </div>` : ''}
            <div id="sg-record-host"></div>
        </div>
    `;

    const host = container.querySelector('#sg-record-host');
    const paint = (idx) => {
        const s = subjects[idx];
        if (!s || !host) return;
        const record = buildStudentRecord(s, myName, myStudentId);
        host.innerHTML = renderClassRecordTable(s, record, { embedded: false });
        bindQuizReviewTriggers(host);
        const hash = `#student/grades?subject_id=${s.subject_id}`;
        if (window.location.hash !== hash) history.replaceState(null, '', hash);
    };

    paint(activeIdx);

    const sel = container.querySelector('#sg-subject-select');
    sel?.addEventListener('change', () => paint(parseInt(sel.value, 10)));
}

function renderClassRecordOnly(container, { subject, myName, myStudentId }) {
    const record = buildStudentRecord(subject, myName, myStudentId);
    container.innerHTML = `
        <style>${pageCss()}${curriculumTableCss()}</style>
        <div class="sg-page sg-embedded">
            <div id="sg-record-host">${renderClassRecordTable(subject, record, { embedded: true })}</div>
        </div>
    `;
    bindQuizReviewTriggers(container);
}

/* ─── Build student record (all items, no period filter) ────── */

function buildStudentRecord(subject, myName, myStudentId) {
    const quizzes = subject.quizzes || [];
    const lessons = subject.lessons || [];
    const periodGroups = buildPeriodGroups(quizzes, lessons, 0);
    const allItems = periodGroups.flat;

    const quizScoreMap = {};
    for (const q of quizzes) {
        const hasAttempt = Number(q.attempts) > 0 || q.best_attempt_id != null || q.best_score != null;
        if (!hasAttempt) continue;
        const earned = q.earned_points != null && q.earned_points !== '' ? parseFloat(q.earned_points) : 0;
        let total = parseFloat(q.total_points);
        if (!Number.isFinite(total) || total < 0) total = 0;
        quizScoreMap[q.quiz_id] = {
            earned, total,
            passed: q.passed == 1,
            best_attempt_id: q.best_attempt_id,
            pending: q.has_pending_grades == 1,
        };
    }

    const lessonStatusMap = {};
    for (const l of lessons) {
        lessonStatusMap[l.lessons_id] = l.progress_status;
    }

    let totalEarned = 0, totalPossible = 0, missingCount = 0;
    for (const item of allItems) {
        if (item.kind === 'quiz') {
            const cell = quizScoreMap[item.id];
            if (cell) {
                totalEarned   += parseFloat(cell.earned) || 0;
                totalPossible += parseFloat(cell.total)  || 0;
            } else if (isItemMissing(item)) {
                missingCount++;
            }
        } else if (lessonStatusMap[item.id] !== 'completed' && isItemMissing(item)) {
            missingCount++;
        }
    }

    const quizItems = allItems.filter(i => i.kind === 'quiz');
    const anyScore  = totalPossible > 0;
    const allPassed = quizItems.length > 0 && quizItems.every(q => quizScoreMap[q.id]?.passed);
    const belowPass = anyScore && totalEarned / totalPossible < 0.6;
    const atRisk    = belowPass || missingCount >= 2;
    const remark    = !anyScore && missingCount > 0 ? 'At risk'
        : !anyScore ? '—'
        : allPassed ? 'Passed'
        : atRisk ? 'At risk' : 'In progress';

    const completedLessons = lessons.filter(l => l.progress_status === 'completed').length;

    return {
        allItems,
        quizScoreMap,
        lessonStatusMap,
        quizzes,
        totalEarned,
        totalPossible,
        missingCount,
        atRisk,
        remark,
        anyScore,
        myName,
        myStudentId,
        completedLessons,
        totalLessons: lessons.length,
        passedQuizzes: quizzes.filter(q => q.passed == 1).length,
        totalQuizzes: quizzes.length,
    };
}

/* ─── Table header (two-row design matching original) ──────── */

function renderTableHeaders(allItems) {
    const colCount = Math.max(allItems.length, 1);
    let periodRow = `<th rowspan="2">#</th><th rowspan="2" class="th-left">Student ID</th><th rowspan="2" class="th-left">Name</th>`;
    periodRow += `<th colspan="${colCount}" class="gb-period-th gb-period-th--p1">Activities &amp; Quizzes</th>`;
    periodRow += `<th rowspan="2">Total</th><th rowspan="2">Remarks</th>`;

    let itemRow = '';
    if (allItems.length) {
        for (const item of allItems) {
            const typeLabel = item.kind === 'quiz' ? 'Quiz' : 'Activity';
            const short     = item.title.length > 16 ? `${item.title.slice(0, 14)}…` : item.title;
            const pts       = item.kind === 'quiz' && item.totalPoints ? ` · ${item.totalPoints}pts` : '';
            itemRow += `<th class="gb-item-th" title="${esc(item.title)} (${typeLabel})${pts}">
                <span class="gb-item-type ${item.kind === 'quiz' ? 'quiz' : 'activity'}">${typeLabel}</span>
                <span class="gb-item-name">${esc(short)}</span>
            </th>`;
        }
    } else {
        itemRow += `<th class="gb-item-th gb-item-th--empty">—</th>`;
    }

    return { periodRow, itemRow };
}

function renderStudentItemCell(record, item) {
    const { quizScoreMap, lessonStatusMap, quizzes } = record;

    if (item.kind === 'quiz') {
        const cell = quizScoreMap[item.id];
        if (!cell) {
            const missing = isItemMissing(item);
            return `<td class="td-num"><span class="${missing ? 'gc-cur-badge-missing' : 'gc-cur-badge-none'}">${missing ? 'Missing' : '—'}</span></td>`;
        }
        const scoreHtml = cell.pending && cell.earned === 0
            ? 'Submitted'
            : `${cell.earned}`;
        const q = quizzes.find(x => String(x.quiz_id) === String(item.id));
        const inner = q?.best_attempt_id
            ? `<button type="button" class="sg-cell-link sg-review-btn" data-quiz-review="${q.best_attempt_id}" title="See your answers">${scoreHtml}</button>`
            : scoreHtml;
        return `<td class="td-num"><span class="gc-cur-badge-raw">${inner}</span></td>`;
    }

    const done = lessonStatusMap[item.id] === 'completed';
    if (done) return `<td class="td-num"><span class="gc-cur-badge-pass">Done</span></td>`;
    if (isItemMissing(item)) return `<td class="td-num"><span class="gc-cur-badge-missing">Missing</span></td>`;
    return `<td class="td-num"><span class="gc-cur-badge-none">—</span></td>`;
}

/* ─── Render the table ─────────────────────────────────────── */

function renderClassRecordTable(subject, record, { embedded = false } = {}) {
    const {
        allItems, totalEarned, totalPossible, atRisk, remark, anyScore,
        myName, myStudentId, completedLessons, totalLessons,
        passedQuizzes, totalQuizzes,
    } = record;

    const meta = [
        esc(subject.subject_code),
        esc(subject.subject_name),
        subject.section_name ? esc(subject.section_name) : '',
        subject.instructor_name ? `Instructor: ${esc(subject.instructor_name)}` : '',
    ].filter(Boolean).join(' · ');

    const totalLabel = totalPossible > 0
        ? `<strong>${totalEarned} / ${totalPossible}</strong>`
        : '<span class="gc-cur-badge-none">—</span>';

    const totalItems = allItems.length;
    const headHtml = `
        <div class="gb-record-head">
            <span class="gb-role-pill">${icon('gradebook', inl)} Student view</span>
            <h2>Class Record</h2>
            <p>${meta}</p>
            <p class="gb-period-legend">All published activities and quizzes. Activities show completion status; quizzes show your raw score.</p>
            <div class="gb-record-stats">
                <span><strong>1</strong> student (you)</span>
                <span><strong>${totalItems}</strong> item${totalItems !== 1 ? 's' : ''}</span>
                <span><strong>${passedQuizzes}/${totalQuizzes}</strong> quizzes passed</span>
                <span><strong>${completedLessons}/${totalLessons}</strong> activities done</span>
                ${totalPossible > 0 ? `<span class="gb-total-pill"><strong>${totalEarned} / ${totalPossible}</strong> total</span>` : ''}
            </div>
        </div>`;

    if (!allItems.length) {
        return `${headHtml}${emptyBox('No activities or quizzes published for this subject yet.')}`;
    }

    const { periodRow, itemRow } = renderTableHeaders(allItems);

    let itemCells = '';
    for (const item of allItems) {
        itemCells += renderStudentItemCell(record, item);
    }

    const studentRow = `
        <tr class="${atRisk ? 'gb-at-risk' : ''}">
            <td class="td-rank">1</td>
            <td class="td-id">${esc(myStudentId || '—')}</td>
            <td class="td-name">${esc(myName)}${atRisk ? ' <span class="gb-risk-tag">!</span>' : ''}</td>
            ${itemCells}
            <td class="td-num">${totalLabel}</td>
            <td class="td-pass"><span class="${atRisk && anyScore ? 'gc-cur-badge-fail' : 'gc-cur-badge-pass'}">${remark}</span></td>
        </tr>`;

    return `
        ${headHtml}
        <div class="gc-cur-wrap">
            <div class="gc-cur-label">CLASS RECORD — ${esc(subject.subject_code)}${subject.section_name ? ` / ${esc(subject.section_name)}` : ''}</div>
            <div class="gb-table-scroll">
                <table class="gc-cur-table gb-record-table gb-period-table">
                    <thead>
                        <tr>${periodRow}</tr>
                        <tr>${itemRow}</tr>
                    </thead>
                    <tbody>${studentRow}</tbody>
                </table>
            </div>
        </div>
        ${embedded ? '' : `
        <p class="sg-footnote">
            ${icon('info', { size: 14, className: 'ui-icon-inline' })}
            Quizzes show your raw score. Activities show completion status.
        </p>`}
    `;
}

/* ─── Shared UI ────────────────────────────────────────────── */

function renderHero(title, sub) {
    return `
        <header class="sg-hero">
            <div>
                <span class="sg-role-pill light">${icon('graduation', inl)} Student view</span>
                <h1 class="sg-hero-title">${esc(title)}</h1>
                <p class="sg-hero-sub">${esc(sub)}</p>
            </div>
        </header>
    `;
}

function emptyBox(msg) {
    return `
        <div class="sg-empty-state">
            <div class="sg-empty-icon">${iconLg('clipboard')}</div>
            <p>${esc(msg)}</p>
        </div>
    `;
}

function pageCss() {
    return `
        ${gradingPeriodTableCss()}
        .sg-page { width:100%; }
        .sg-embedded { padding:0; }
        .sg-loading { display:flex; align-items:center; justify-content:center; min-height:200px; }
        .sg-spin { width:36px; height:36px; border:3px solid #eee; border-top-color:${G}; border-radius:50%; animation:sgSpin .75s linear infinite; }
        @keyframes sgSpin { to { transform:rotate(360deg); } }

        .sg-hero { padding:24px 28px; margin-bottom:20px; border-radius:16px; color:#fff; background:${G};
            box-shadow:0 4px 16px rgba(0,70,27,.15); }
        .sg-hero-title { font-size:24px; font-weight:800; margin:8px 0 4px; }
        .sg-hero-sub { font-size:13px; opacity:.85; margin:0; }

        .sg-role-pill, .gb-role-pill {
            display:inline-flex; align-items:center; gap:5px; padding:4px 10px; border-radius:20px;
            font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:.5px;
            background:${GL}; color:${G};
        }
        .sg-role-pill.light { background:rgba(255,255,255,.18); color:#fff; }

        .sg-subject-bar {
            display:flex; align-items:center; gap:14px; flex-wrap:wrap;
            background:#fff; border:1px solid ${BORDER}; border-radius:12px;
            padding:14px 18px; margin-bottom:18px; box-shadow:0 1px 3px rgba(0,0,0,.05);
        }
        .sg-subject-bar-label { font-size:13px; font-weight:700; color:#374151; white-space:nowrap; }
        .sg-subject-select-wrap { position:relative; flex:1; max-width:420px; min-width:200px; }
        .sg-subject-chevron { position:absolute; right:12px; top:50%; transform:translateY(-50%); pointer-events:none; color:#6b7280; }
        .sg-subject-select {
            width:100%; padding:10px 38px 10px 14px; border:1.5px solid #e5e7eb; border-radius:10px;
            font-size:14px; font-weight:600; color:#111827; background:#fff; appearance:none;
            -webkit-appearance:none; cursor:pointer; outline:none; font-family:inherit;
        }
        .sg-subject-select:focus { border-color:${G}; box-shadow:0 0 0 3px rgba(0,70,27,.1); }
        .sg-subject-hint { font-size:12px; color:#9CA3AF; margin-left:auto; }

        .gb-record-head { margin-bottom:16px; }
        .gb-record-head h2 { font-size:20px; font-weight:800; color:#111; margin:8px 0 4px; }
        .gb-record-head > p { font-size:13px; color:#6B7280; margin:0 0 10px; }
        .gb-period-legend { font-size:12px !important; color:#00461B !important; background:#E8F5EC;
            padding:8px 12px; border-radius:8px; margin-bottom:10px !important; }
        .gb-record-stats { display:flex; flex-wrap:wrap; gap:16px; align-items:center; font-size:13px; color:#374151; }
        .gb-record-stats strong { color:${G}; }
        .gb-total-pill { margin-left:auto; padding:6px 14px; border-radius:20px; background:${GL}; font-weight:700; color:${G}; }

        .gb-item-pts { display:block; font-size:8px; color:#9ca3af; margin-top:1px; }

        .gb-at-risk { background:#FEF2F2 !important; }
        .gb-risk-tag { display:inline-flex; align-items:center; justify-content:center; width:16px; height:16px;
            border-radius:50%; background:#FEE2E2; color:#B91C1C; font-size:10px; font-weight:800; margin-left:4px; }
        .gc-cur-badge-missing { display:inline-block; padding:3px 8px; border-radius:6px; font-size:11px; font-weight:700;
            background:#FEF3C7; color:#B45309; }
        .gc-cur-badge-raw { font-size:12px; font-weight:700; color:#111827; }
        .sg-cell-link { color:#00461B; text-decoration:none; font-weight:700; background:none; border:none;
            padding:0; cursor:pointer; font:inherit; font-size:inherit; }
        .sg-cell-link:hover { text-decoration:underline; }

        .gb-table-scroll { overflow-x:auto; }
        .gb-record-table { min-width:640px; }

        .sg-empty-state { text-align:center; padding:48px 24px; border:2px dashed ${BORDER}; border-radius:16px; background:#FAFAFA; }
        .sg-empty-icon { margin-bottom:12px; color:#9CA3AF; }
        .sg-empty-state p { color:#6B7280; margin:0; }

        .sg-footnote { display:flex; align-items:flex-start; gap:8px; margin-top:16px; padding:12px 14px;
            background:#F8FDF9; border:1px solid #C5D9CB; border-radius:10px; font-size:12px; color:#374151; line-height:1.5; }

        @media(max-width:640px) {
            .gb-total-pill { margin-left:0; width:100%; text-align:center; }
            .sg-subject-hint { margin-left:0; width:100%; }
        }
    `;
}
