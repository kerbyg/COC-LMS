/**
 * Student Quiz Result Page
 * Display quiz attempt results with score and answer review
 */
import { Api } from '../../api.js';
import { icon } from '../../utils/icons.js';
import { subjectHash } from './quizzes.js';
import { openStudentQuizReviewModal } from '../../components/student-quiz-review-modal.js';

const inl = { size: 14, className: 'ui-icon-inline' };

export async function render(container) {
    const params = new URLSearchParams(window.location.hash.split('?')[1] || '');
    const attemptId = params.get('attempt_id');

    if (!attemptId) {
        container.innerHTML = '<div style="text-align:center;padding:60px;color:#737373">No attempt selected. <a href="#student/my-subjects" style="color:#1B4D3E">Go to My Subjects</a></div>';
        return;
    }

    const res = await Api.get('/ProgressAPI.php?action=quiz-result&attempt_id=' + attemptId);
    if (!res.success) {
        container.innerHTML = `<div style="text-align:center;padding:60px;color:#b91c1c">${res.message || 'Failed to load result'}</div>`;
        return;
    }

    const attempt = res.data.attempt;
    const answers = res.data.answers || [];
    const wrongAnswers = res.data.wrong_answers || [];
    const showAnswers = res.data.show_answers;
    const lessonsId = res.data.lessons_id || null;
    const lessonTitle = res.data.lesson_title || null;
    const pct = parseFloat(attempt.percentage || 0);
    const passed = attempt.passed == 1;
    const timeTaken = parseInt(attempt.time_spent || 0);
    const minutes = Math.floor(timeTaken / 60);
    const seconds = timeTaken % 60;

    container.innerHTML = `
        <style>
            .result-container { max-width:800px; margin:0 auto; }

            .result-hero { border-radius:16px; padding:40px; text-align:center; margin-bottom:24px; color:#fff; }
            .result-hero.pass { background:#00461B; }
            .result-hero.fail { background:#b91c1c; }
            .score-circle { width:100px; height:100px; border-radius:50%; background:rgba(255,255,255,.15); display:flex; align-items:center; justify-content:center; margin:0 auto 16px; }
            .score-num { font-size:32px; font-weight:800; }
            .result-label { font-size:20px; font-weight:700; margin-bottom:4px; }
            .result-sub { opacity:.8; font-size:14px; }

            .stats-row { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-bottom:24px; }
            .stat-card { background:#fff; border:1px solid #e8e8e8; border-radius:12px; padding:16px; text-align:center; }
            .stat-card .num { font-size:20px; font-weight:800; color:#262626; }
            .stat-card .label { font-size:12px; color:#737373; margin-top:2px; }

            .actions-row { display:flex; gap:12px; margin-bottom:24px; justify-content:center; flex-wrap:wrap; }
            .btn { padding:10px 20px; border-radius:10px; font-size:14px; font-weight:600; text-decoration:none; border:1px solid #e0e0e0; background:#fff; color:#404040; display:inline-flex; align-items:center; gap:6px; cursor:pointer; font-family:inherit; }
            .btn:hover { background:#f5f5f5; }
            .btn.primary { background:#00461B; color:#fff; border-color:#00461B; }
            .btn.review { background:#FEF3C7; color:#92400E; border-color:#FDE68A; }

            .review-section { margin-top:24px; }
            .review-title { font-size:18px; font-weight:700; color:#262626; margin-bottom:16px; }
            .answer-card { background:#fff; border:1px solid #e8e8e8; border-radius:12px; padding:18px; margin-bottom:12px; }
            .answer-card.wrong { border-color:#FECACA; background:#FFFBFB; }
            .ac-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
            .ac-num { font-size:13px; color:#737373; }
            .ac-badge { padding:3px 8px; border-radius:12px; font-size:11px; font-weight:600; }
            .ac-correct { background:#E8F5E9; color:#1B4D3E; }
            .ac-wrong { background:#FEE2E2; color:#b91c1c; }
            .ac-pending { background:#FEF3C7; color:#B45309; }
            .ac-question { font-size:15px; font-weight:600; color:#262626; margin-bottom:12px; }
            .ac-answer-block { margin-bottom:8px; }
            .ac-lbl { font-size:10px; font-weight:700; text-transform:uppercase; color:#6B7280; margin-bottom:4px; }
            .ac-val { padding:8px 10px; border-radius:8px; font-size:13px; background:#F9FAFB; border:1px solid #E5E7EB; }
            .ac-val.bad { background:#FEE2E2; border-color:#FECACA; color:#991B1B; }
            .ac-val.good { background:#ECFDF5; border-color:#A7F3D0; color:#065F46; }
            .ac-options { display:flex; flex-direction:column; gap:6px; }
            .ac-option { padding:8px 12px; border-radius:8px; font-size:13px; display:flex; align-items:center; gap:8px; justify-content:space-between; }
            .ac-option.correct-selected { background:#E8F5E9; border:1px solid #2D6A4F; color:#1B4D3E; }
            .ac-option.wrong-selected { background:#FEE2E2; border:1px solid #fca5a5; color:#b91c1c; }
            .ac-option.correct-answer { background:#f0fdf4; border:1px solid #bbf7d0; color:#1B4D3E; }
            .ac-option.neutral { background:#fafafa; border:1px solid #e8e8e8; color:#404040; }
            .ac-indicator { font-size:12px; font-weight:700; }
            .ac-feedback { font-size:12px; color:#374151; font-style:italic; margin-top:8px; padding:8px; background:#F3F4F6; border-radius:8px; }

            .empty-state-sm { text-align:center; padding:20px; color:#737373; font-size:14px; }
            @media(max-width:768px) { .stats-row { grid-template-columns:1fr 1fr; } }
        </style>

        <div class="result-container">
            <div class="result-hero ${passed ? 'pass' : 'fail'}">
                <div class="score-circle"><span class="score-num">${pct.toFixed(1)}%</span></div>
                <div class="result-label">${passed ? 'Congratulations!' : 'Keep Trying!'}</div>
                <div class="result-sub">${esc(attempt.quiz_title)} · ${esc(attempt.subject_code)}</div>
            </div>

            <div class="stats-row">
                <div class="stat-card"><div class="num">${attempt.earned_points}/${attempt.total_points}</div><div class="label">Points</div></div>
                <div class="stat-card"><div class="num">${pct.toFixed(1)}%</div><div class="label">Score</div></div>
                <div class="stat-card"><div class="num">${wrongAnswers.length}</div><div class="label">To Review</div></div>
                <div class="stat-card"><div class="num">${attempt.passing_rate}%</div><div class="label">Passing</div></div>
            </div>

            <div class="actions-row">
                ${wrongAnswers.length ? `<button type="button" class="btn review" id="qr-open-review">${icon('chart', inl)} Where I went wrong (${wrongAnswers.length})</button>` : ''}
                ${attempt.subject_id ? `<a class="btn" href="${subjectHash(attempt.subject_id, 'classwork', { type: 'quiz', id: attempt.quiz_id })}">${icon('quiz', inl)} Back to Classwork</a>` : ''}
                ${passed && lessonsId ? `<a class="btn primary" href="#student/lessons">${icon('checkCircle', inl)} Continue to Next Lesson</a>` : ''}
            </div>

            ${wrongAnswers.length > 0 ? `
            <div class="review-section">
                <div class="review-title">${icon('chart', inl)} Where you went wrong</div>
                ${wrongAnswers.map((a, i) => renderAnswerCard(a, answers.indexOf(a), showAnswers)).join('')}
            </div>` : answers.length ? `
            <div class="review-section">
                <div class="review-title">Answer Review</div>
                ${answers.map((a, i) => renderAnswerCard(a, i, showAnswers)).join('')}
            </div>` : '<div class="empty-state-sm">Answer review is not available for this quiz</div>'}
        </div>
    `;

    container.querySelector('#qr-open-review')?.addEventListener('click', () => {
        openStudentQuizReviewModal(attemptId);
    });
}

function renderAnswerCard(a, index, showAnswers) {
    const qType = (a.question_type || '').toLowerCase();
    const isMc        = ['multiple_choice', 'true_false', 'dropdown'].includes(qType);
    const isCheckboxQ = qType === 'checkboxes';
    const pending = a.is_pending;
    const wrong = a.is_wrong;
    const badge = pending
        ? '<span class="ac-badge ac-pending">Pending review</span>'
        : wrong
            ? `<span class="ac-badge ac-wrong">Wrong · ${a.points_earned}/${a.max_points} pts</span>`
            : `<span class="ac-badge ac-correct">Correct · ${a.points_earned}/${a.max_points} pts</span>`;

    let body = '';
    if ((isMc || isCheckboxQ) && (a.options || []).length) {
        // For checkboxes: selected_option_ids is a comma-separated string stored in answer_text
        const selectedIds = isCheckboxQ
            ? (a.answer_text || '').split(',').map(s => s.trim()).filter(Boolean)
            : [];
        body = `<div class="ac-options">${(a.options || []).map(o => {
            const isSelected = isCheckboxQ
                ? selectedIds.includes(String(o.option_id))
                : String(o.option_id) === String(a.selected_option_id);
            const isCorrectOpt = o.is_correct == 1;
            let cls = 'neutral';
            let indicator = '';
            if (isSelected && isCorrectOpt) { cls = 'correct-selected'; indicator = isCheckboxQ ? '✓' : 'Your answer ✓'; }
            else if (isSelected) { cls = 'wrong-selected'; indicator = isCheckboxQ ? '✗' : 'Your answer ✗'; }
            else if (showAnswers && isCorrectOpt) { cls = 'correct-answer'; indicator = 'Correct'; }
            return `<div class="ac-option ${cls}"><span>${esc(o.option_text)}</span>${indicator ? `<span class="ac-indicator">${indicator}</span>` : ''}</div>`;
        }).join('')}</div>`;
        if (isCheckboxQ && showAnswers) {
            body += `<div style="font-size:12px;color:#737373;margin-top:8px;padding:6px 10px;background:#f9f9f9;border-radius:6px;">Select ALL correct answers for full points.</div>`;
        }
    } else {
        const yours = a.your_answer_text || a.answer_text || a.selected_option_text || '(no answer)';
        body = `<div class="ac-answer-block"><div class="ac-lbl">Your answer</div>
            <div class="ac-val ${wrong ? 'bad' : ''}">${esc(yours)}</div></div>`;
        if (showAnswers && a.correct_answer_text) {
            body += `<div class="ac-answer-block"><div class="ac-lbl">Expected answer</div>
                <div class="ac-val good">${esc(a.correct_answer_text)}</div></div>`;
        }
    }
    if (a.grader_feedback) {
        body += `<div class="ac-feedback">${esc(a.grader_feedback)}</div>`;
    }

    return `
        <div class="answer-card ${wrong ? 'wrong' : ''}">
            <div class="ac-header">
                <span class="ac-num">Question ${index + 1}</span>
                ${badge}
            </div>
            <div class="ac-question">${esc(a.question_text)}</div>
            ${body}
        </div>`;
}

function esc(str) { const d = document.createElement('div'); d.textContent = str || ''; return d.innerHTML; }
