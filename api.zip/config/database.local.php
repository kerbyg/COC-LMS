<?php
/**
 * Local database override — not committed to git.
 * Created because the original cit_lms database had orphaned table files.
 */
$dbName = 'cit_lms';
