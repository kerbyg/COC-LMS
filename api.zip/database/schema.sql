﻿-- =============================================================
-- COC-LMS Database Schema
-- Database: cit_lms  |  Tables: 41
-- =============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

-- -------------------------------------------------------------
-- USERS & AUTHENTICATION
-- -------------------------------------------------------------

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `users_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(20) DEFAULT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','dean','instructor','student') NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `major` varchar(120) DEFAULT NULL,
  `year_level` int(11) DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`users_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `employee_id` (`employee_id`),
  UNIQUE KEY `student_id` (`student_id`),
  KEY `department_id` (`department_id`),
  KEY `program_id` (`program_id`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_student_id` (`student_id`),
  KEY `idx_users_employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `campus`;
CREATE TABLE `campus` (
  `campus_id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_name` varchar(100) NOT NULL,
  `campus_code` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`campus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `password_otp`;
CREATE TABLE `password_otp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `users_id` int(10) unsigned NOT NULL,
  `otp_hash` varchar(255) NOT NULL,
  `new_password_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_password_otp_user` (`users_id`),
  KEY `idx_password_otp_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) DEFAULT NULL,
  `activity_type` varchar(50) NOT NULL,
  `activity_description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `users_id` (`users_id`),
  KEY `idx_activity_type` (`activity_type`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`users_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=854 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- RBAC - ROLES & PERMISSIONS
-- -------------------------------------------------------------

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL COMMENT 'Slug e.g. users.create',
  `description` varchar(200) NOT NULL,
  `module` varchar(50) NOT NULL COMMENT 'Grouping key e.g. users',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_perm_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` enum('admin','dean','instructor','student') NOT NULL,
  `permission_id` int(11) NOT NULL,
  `granted_by` int(11) DEFAULT NULL COMMENT 'users_id who last set this',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_perm` (`role`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  KEY `granted_by` (`granted_by`)
) ENGINE=InnoDB AUTO_INCREMENT=678 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','number','boolean','json') DEFAULT 'string',
  `description` text DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 0,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `updated_by` (`updated_by`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- ACADEMIC STRUCTURE
-- -------------------------------------------------------------

DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_id` int(11) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `department_code` varchar(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`department_id`),
  KEY `campus_id` (`campus_id`),
  CONSTRAINT `department_ibfk_1` FOREIGN KEY (`campus_id`) REFERENCES `campus` (`campus_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `program`;
CREATE TABLE `program` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `program_name` varchar(100) NOT NULL,
  `program_code` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `degree_level` enum('certificate','associate','bachelor','master','doctorate') DEFAULT 'bachelor',
  `total_units` int(11) DEFAULT 0,
  `duration_years` int(11) DEFAULT 4,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`program_id`),
  KEY `department_id` (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `department_program`;
CREATE TABLE `department_program` (
  `dept_program_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  PRIMARY KEY (`dept_program_id`),
  UNIQUE KEY `uq_dept_program` (`department_id`,`program_id`),
  KEY `fk_dp_program` (`program_id`),
  CONSTRAINT `fk_dp_department` FOREIGN KEY (`department_id`) REFERENCES `department` (`department_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_dp_program` FOREIGN KEY (`program_id`) REFERENCES `program` (`program_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sem_type`;
CREATE TABLE `sem_type` (
  `sem_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `sem_level` int(11) NOT NULL,
  PRIMARY KEY (`sem_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `semester`;
CREATE TABLE `semester` (
  `semester_id` int(11) NOT NULL AUTO_INCREMENT,
  `semester_name` varchar(100) NOT NULL,
  `academic_year` varchar(20) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','inactive','upcoming') DEFAULT 'inactive',
  `sem_type_id` int(11) NOT NULL,
  PRIMARY KEY (`semester_id`),
  UNIQUE KEY `uq_semester_ay_type` (`academic_year`,`sem_type_id`),
  KEY `sem_type_id` (`sem_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `subject`;
CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) DEFAULT NULL,
  `subject_code` varchar(20) NOT NULL,
  `subject_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `units` int(11) DEFAULT 3,
  `year_level` int(11) DEFAULT NULL,
  `semester` int(11) DEFAULT NULL,
  `lecture_hours` int(11) DEFAULT 3,
  `lab_hours` int(11) DEFAULT 0,
  `pre_requisite` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `semester_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`subject_id`),
  UNIQUE KEY `subject_code` (`subject_code`),
  KEY `idx_subject_code` (`subject_code`),
  KEY `idx_subject_status` (`status`),
  KEY `idx_program_id` (`program_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1951 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `curriculum`;
CREATE TABLE `curriculum` (
  `curriculum_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `year_level` int(11) NOT NULL,
  `academic_year` varchar(20) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `semester_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`curriculum_id`),
  UNIQUE KEY `uq_curriculum_program_course` (`program_id`,`course_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `curriculum_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `program` (`program_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=881 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `section`;
CREATE TABLE `section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_name` varchar(20) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `year_level` tinyint(1) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `enrollment_code` varchar(20) NOT NULL,
  `max_students` int(11) DEFAULT 40,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`section_id`),
  UNIQUE KEY `enrollment_code` (`enrollment_code`),
  UNIQUE KEY `uq_enrollment_code` (`enrollment_code`),
  KEY `idx_section_program` (`program_id`),
  KEY `idx_section_semester` (`semester_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- FACULTY & OFFERINGS
-- -------------------------------------------------------------

DROP TABLE IF EXISTS `faculty_subject`;
CREATE TABLE `faculty_subject` (
  `faculty_subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_teacher_id` int(11) NOT NULL,
  `subject_offered_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`faculty_subject_id`),
  UNIQUE KEY `unique_assignment` (`user_teacher_id`,`subject_offered_id`),
  KEY `subject_offered_id` (`subject_offered_id`),
  KEY `section_id` (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `subject_offered`;
CREATE TABLE `subject_offered` (
  `subject_offered_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `batch` enum('1st Year','2nd Year','3rd Year','4th Year') DEFAULT NULL,
  `user_teacher_id` int(11) DEFAULT NULL,
  `max_students` int(11) DEFAULT 40,
  `status` enum('open','closed','cancelled') DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `current_period` varchar(2) NOT NULL DEFAULT 'P1' COMMENT 'Current released grading period: P1=Midterms P2=Prefinals P3=Finals',
  PRIMARY KEY (`subject_offered_id`),
  KEY `fk_subject_offered_teacher` (`user_teacher_id`),
  KEY `idx_subject_id` (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `section_subject`;
CREATE TABLE `section_subject` (
  `section_subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `subject_offered_id` int(11) NOT NULL,
  `schedule` varchar(100) DEFAULT NULL,
  `room` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`section_subject_id`),
  UNIQUE KEY `uq_sec_subj` (`section_id`,`subject_offered_id`),
  KEY `fk_secsubj_section` (`section_id`),
  KEY `fk_secsubj_offered` (`subject_offered_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -------------------------------------------------------------
-- LESSONS & CONTENT
-- -------------------------------------------------------------

DROP TABLE IF EXISTS `lessons`;
CREATE TABLE `lessons` (
  `lessons_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `user_teacher_id` int(11) NOT NULL,
  `lesson_title` varchar(200) NOT NULL,
  `lesson_description` text DEFAULT NULL,
  `learning_objectives` text DEFAULT NULL COMMENT 'JSON array of objectives',
  `prerequisite_lessons_id` int(11) DEFAULT NULL,
  `lesson_content` longtext DEFAULT NULL,
  `lesson_order` int(11) DEFAULT 1,
  `estimated_time` int(11) DEFAULT 30,
  `difficulty` enum('beginner','intermediate','advanced') DEFAULT 'beginner',
  `status` enum('draft','published','archived') DEFAULT 'draft',
  `due_date` date DEFAULT NULL COMMENT 'Last day students can turn in work',
  `grading_period` varchar(2) NOT NULL DEFAULT 'P1' COMMENT 'P1=Midterms P2=Prefinals P3=Finals',
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`lessons_id`),
  KEY `idx_lessons_subject` (`subject_id`),
  KEY `idx_lessons_teacher` (`user_teacher_id`),
  KEY `idx_lessons_status` (`status`),
  CONSTRAINT `lessons_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE,
  CONSTRAINT `lessons_ibfk_2` FOREIGN KEY (`user_teacher_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lesson_section`;
CREATE TABLE `lesson_section` (
  `lessons_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`lessons_id`,`section_id`),
  KEY `idx_lesson_section` (`section_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `lesson_materials`;
CREATE TABLE `lesson_materials` (
  `material_id` int(11) NOT NULL AUTO_INCREMENT,
  `lessons_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `material_type` enum('document','video','audio','image','link','other') DEFAULT 'document',
  `description` text DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`material_id`),
  KEY `fk_materials_lesson` (`lessons_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lesson_bank`;
CREATE TABLE `lesson_bank` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `lesson_title` varchar(200) NOT NULL,
  `lesson_description` text DEFAULT NULL,
  `lesson_content` longtext DEFAULT NULL,
  `attachment_type` enum('none','file','link') DEFAULT 'none',
  `attachment_path` varchar(500) DEFAULT NULL,
  `attachment_name` varchar(200) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `visibility` enum('public','private') DEFAULT 'public',
  `tags` varchar(500) DEFAULT NULL,
  `copy_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`bank_id`),
  KEY `created_by` (`created_by`),
  KEY `subject_id` (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- QUIZZES & ASSESSMENTS
-- -------------------------------------------------------------

DROP TABLE IF EXISTS `quiz`;
CREATE TABLE `quiz` (
  `quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `user_teacher_id` int(11) NOT NULL,
  `quiz_title` varchar(200) NOT NULL,
  `quiz_description` text DEFAULT NULL,
  `quiz_type` enum('pre_test','post_test','practice','graded') DEFAULT 'graded',
  `grading_period` varchar(2) NOT NULL DEFAULT 'P1' COMMENT 'P1=Midterms P2=Prefinals P3=Finals',
  `time_limit` int(11) DEFAULT 30,
  `passing_rate` decimal(5,2) DEFAULT 60.00,
  `max_attempts` int(11) DEFAULT 3,
  `total_points` int(11) DEFAULT 0,
  `is_randomized` tinyint(1) DEFAULT 0,
  `show_answers` tinyint(1) DEFAULT 1,
  `availability_start` timestamp NULL DEFAULT NULL,
  `availability_end` timestamp NULL DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('draft','published','closed','archived') DEFAULT 'draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `one_at_a_time` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Show one question at a time; student cannot go back',
  `objective_grading_mode` varchar(20) NOT NULL DEFAULT 'auto' COMMENT 'auto|ai_auto|ai_review|manual ? MC/TF always auto-scored',
  `subjective_grading_mode` varchar(20) NOT NULL DEFAULT 'ai_auto' COMMENT 'manual|ai_auto|ai_review|answer_key',
  PRIMARY KEY (`quiz_id`),
  KEY `user_teacher_id` (`user_teacher_id`),
  KEY `idx_quiz_subject` (`subject_id`),
  KEY `idx_quiz_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `quiz_lessons`;
CREATE TABLE `quiz_lessons` (
  `quiz_lessons_id` int(11) NOT NULL AUTO_INCREMENT,
  `lessons_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  PRIMARY KEY (`quiz_lessons_id`),
  KEY `idx_quiz_lessons_lesson` (`lessons_id`),
  KEY `idx_quiz_lessons_quiz` (`quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `quiz_section`;
CREATE TABLE `quiz_section` (
  `quiz_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`quiz_id`,`section_id`),
  KEY `idx_quiz_section` (`section_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `quiz_questions`;
CREATE TABLE `quiz_questions` (
  `quiz_questions_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) DEFAULT NULL,
  `questions_id` int(11) NOT NULL,
  `lessons_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`quiz_questions_id`),
  KEY `idx_qq_question` (`questions_id`),
  KEY `idx_qq_lesson` (`lessons_id`),
  KEY `idx_qq_quiz` (`quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `questions_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_text` text NOT NULL,
  `question_type` varchar(50) DEFAULT 'multiple_choice',
  `points` int(11) DEFAULT 1,
  `question_order` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `users_id` int(11) NOT NULL COMMENT 'Teacher who created the question',
  `lessons_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`questions_id`),
  KEY `idx_questions_user` (`users_id`),
  KEY `idx_questions_lesson` (`lessons_id`),
  KEY `idx_questions_type` (`question_type`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `question_option`;
CREATE TABLE `question_option` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_question_id` int(11) NOT NULL,
  `option_text` text NOT NULL,
  `is_correct` tinyint(1) DEFAULT 0,
  `order_number` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`option_id`),
  KEY `idx_question_id` (`quiz_question_id`),
  KEY `idx_is_correct` (`is_correct`)
) ENGINE=InnoDB AUTO_INCREMENT=550 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Multiple choice options for quiz questions';

DROP TABLE IF EXISTS `question_bank`;
CREATE TABLE `question_bank` (
  `qbank_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_text` text NOT NULL,
  `question_type` varchar(50) DEFAULT 'multiple_choice',
  `points` int(11) DEFAULT 1,
  `subject_id` int(11) DEFAULT NULL,
  `lessons_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `visibility` enum('public','private') DEFAULT 'public',
  `copy_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`qbank_id`),
  KEY `created_by` (`created_by`),
  KEY `subject_id` (`subject_id`),
  KEY `fk_qbank_lesson` (`lessons_id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `question_bank_options`;
CREATE TABLE `question_bank_options` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `qbank_id` int(11) NOT NULL,
  `option_text` text NOT NULL,
  `is_correct` tinyint(1) DEFAULT 0,
  `option_order` int(11) DEFAULT 1,
  PRIMARY KEY (`option_id`),
  KEY `qbank_id` (`qbank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- STUDENT ACTIVITY
-- -------------------------------------------------------------

DROP TABLE IF EXISTS `student_subject`;
CREATE TABLE `student_subject` (
  `student_subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_student_id` int(11) NOT NULL,
  `subject_offered_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT NULL,
  `enrollment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('enrolled','dropped','completed','failed') DEFAULT 'enrolled',
  `final_grade` decimal(5,2) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`student_subject_id`),
  UNIQUE KEY `unique_enrollment` (`user_student_id`,`subject_offered_id`),
  KEY `subject_offered_id` (`subject_offered_id`),
  KEY `section_id` (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `student_progress`;
CREATE TABLE `student_progress` (
  `progress_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_student_id` int(11) NOT NULL,
  `lessons_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `completion_percentage` decimal(5,2) DEFAULT 0.00,
  `time_spent` int(11) DEFAULT 0,
  `last_accessed` timestamp NOT NULL DEFAULT current_timestamp(),
  `started_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  `status` enum('not_started','in_progress','completed') DEFAULT 'not_started',
  PRIMARY KEY (`progress_id`),
  UNIQUE KEY `unique_progress` (`user_student_id`,`lessons_id`),
  KEY `subject_id` (`subject_id`),
  KEY `idx_progress_student` (`user_student_id`),
  KEY `idx_progress_lesson` (`lessons_id`),
  KEY `idx_progress_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `student_quiz_attempts`;
CREATE TABLE `student_quiz_attempts` (
  `attempt_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `user_student_id` int(11) NOT NULL,
  `attempt_number` int(11) DEFAULT 1,
  `score` decimal(5,2) DEFAULT 0.00,
  `total_points` int(11) DEFAULT 0,
  `earned_points` int(11) DEFAULT 0,
  `percentage` decimal(5,2) DEFAULT 0.00,
  `passed` tinyint(1) DEFAULT 0,
  `time_spent` int(11) DEFAULT 0,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  `status` enum('in_progress','completed','abandoned') DEFAULT 'in_progress',
  `has_pending_grades` tinyint(1) DEFAULT 0,
  `tab_switch_count` int(11) NOT NULL DEFAULT 0 COMMENT 'Number of times student switched tabs or alt-tabbed during the quiz',
  `ip_address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`attempt_id`),
  KEY `idx_attempts_quiz` (`quiz_id`),
  KEY `idx_attempts_student` (`user_student_id`),
  KEY `idx_attempts_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `student_quiz_answers`;
CREATE TABLE `student_quiz_answers` (
  `student_quiz_answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `attempt_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `questions_id` int(11) NOT NULL,
  `user_student_id` int(11) NOT NULL,
  `selected_option_id` int(11) DEFAULT NULL COMMENT 'For multiple choice',
  `answer_text` text DEFAULT NULL COMMENT 'For short answer/essay',
  `is_correct` tinyint(1) DEFAULT NULL,
  `points_earned` decimal(5,2) DEFAULT 0.00,
  `grading_status` enum('auto_graded','pending','graded') DEFAULT 'auto_graded',
  `grader_feedback` text DEFAULT NULL,
  `graded_by` int(11) DEFAULT NULL,
  `graded_at` timestamp NULL DEFAULT NULL,
  `time_spent_seconds` int(11) DEFAULT 0,
  `answered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`student_quiz_answer_id`),
  KEY `idx_attempt_id` (`attempt_id`),
  KEY `idx_quiz_id` (`quiz_id`),
  KEY `idx_question_id` (`questions_id`),
  KEY `idx_student_id` (`user_student_id`),
  KEY `idx_is_correct` (`is_correct`),
  KEY `fk_student_answers_option` (`selected_option_id`),
  KEY `idx_student_answers_lookup` (`attempt_id`,`questions_id`),
  KEY `idx_student_answers_analytics` (`quiz_id`,`questions_id`,`is_correct`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Individual student answers for quiz questions';

DROP TABLE IF EXISTS `student_work_files`;
CREATE TABLE `student_work_files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `lessons_id` int(11) DEFAULT NULL,
  `quiz_id` int(11) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT 'document',
  `file_size` int(11) DEFAULT 0,
  `is_submitted` tinyint(1) NOT NULL DEFAULT 0,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`file_id`),
  KEY `idx_student_lesson` (`user_student_id`,`lessons_id`),
  KEY `idx_student_quiz` (`user_student_id`,`quiz_id`),
  KEY `idx_subject` (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `student_reminder_log`;
CREATE TABLE `student_reminder_log` (
  `reminder_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_student_id` int(10) unsigned NOT NULL,
  `item_type` enum('lesson','quiz','post') NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `stage_key` varchar(64) NOT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `email_to` varchar(190) DEFAULT NULL,
  `status` enum('pending','sent','failed','skipped') NOT NULL DEFAULT 'pending',
  `error_text` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`reminder_id`),
  UNIQUE KEY `uniq_student_item_stage` (`user_student_id`,`item_type`,`item_id`,`stage_key`),
  KEY `idx_student_status` (`user_student_id`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `classwork_views`;
CREATE TABLE `classwork_views` (
  `view_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `user_student_id` int(11) NOT NULL,
  `content_type` varchar(20) NOT NULL,
  `content_id` int(11) NOT NULL,
  `first_viewed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_viewed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `view_count` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`view_id`),
  UNIQUE KEY `uniq_student_content` (`user_student_id`,`subject_id`,`content_type`,`content_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_content` (`content_type`,`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -------------------------------------------------------------
-- COMMUNICATION
-- -------------------------------------------------------------

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `attachment_path` varchar(500) DEFAULT NULL,
  `attachment_name` varchar(200) DEFAULT NULL,
  `attachment_type` varchar(20) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`message_id`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_receiver` (`receiver_id`,`is_read`),
  KEY `idx_thread` (`sender_id`,`receiver_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `announcement`;
CREATE TABLE `announcement` (
  `announcement_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `subject_offered_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `announcement_type` enum('general','urgent','reminder','event') DEFAULT 'general',
  `is_pinned` tinyint(1) DEFAULT 0,
  `is_published` tinyint(1) DEFAULT 1,
  `status` enum('draft','published','archived') DEFAULT 'published',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`announcement_id`),
  KEY `user_id` (`user_id`),
  KEY `subject_offered_id` (`subject_offered_id`),
  KEY `idx_announcement_published` (`is_published`),
  KEY `idx_announcement_type` (`announcement_type`),
  CONSTRAINT `announcement_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE,
  CONSTRAINT `announcement_ibfk_2` FOREIGN KEY (`subject_offered_id`) REFERENCES `subject_offered` (`subject_offered_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `class_comments`;
CREATE TABLE `class_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `lessons_id` int(11) DEFAULT NULL,
  `quiz_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `parent_comment_id` int(11) DEFAULT NULL,
  `thread_user_id` int(11) DEFAULT NULL COMMENT 'Student owner of private thread',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`comment_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_lesson` (`lessons_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `bank_comments`;
CREATE TABLE `bank_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_type` enum('material','question','quiz') NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `parent_comment_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`comment_id`),
  KEY `idx_post` (`post_type`,`post_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SET FOREIGN_KEY_CHECKS = 1;
